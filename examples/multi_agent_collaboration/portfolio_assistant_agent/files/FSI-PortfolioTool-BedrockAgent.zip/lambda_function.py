import pandas as pd
import json
import logging
from pypfopt.efficient_frontier import EfficientFrontier
from pypfopt import risk_models, expected_returns
from pypfopt.discrete_allocation import DiscreteAllocation, get_latest_prices
from pypfopt.risk_models import fix_nonpositive_semidefinite

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(event)
    
    # Extract parameters from the event.
    parameters = {param["name"]: param["value"] for param in event.get("parameters", [])}
    tickers = [t.strip() for t in parameters.get("tickers", "").split(",")]
    prices_data_str = parameters.get("prices", "")
    
    if not tickers or not prices_data_str:
        responseBody = {"TEXT": {"body": "Error: Tickers and prices are required."}}
        return build_response(event, responseBody)
    
    try:
        # Parse the JSON string.
        raw_prices = json.loads(prices_data_str)
        # Detect orientation:
        first_key = next(iter(raw_prices.keys()))
        if first_key in tickers:
            df = pd.DataFrame.from_dict(raw_prices, orient="index").T
        else:
            df = pd.DataFrame.from_dict(raw_prices, orient="index")
        
        # Convert the index to datetime.
        df.index = pd.to_datetime(df.index)
        df = df[tickers]
    except Exception as e:
        logger.error(f"Error processing price data: {str(e)}")
        responseBody = {"TEXT": {"body": "Error: Invalid price data format."}}
        return build_response(event, responseBody)
    
    logger.info(f"Processed DataFrame:\n{df}")
    
    # Compute expected returns and covariance matrix.
    mu = expected_returns.ema_historical_return(df)
    S = risk_models.sample_cov(df)
    S = (S + S.T) / 2
    S = fix_nonpositive_semidefinite(S)
    
    logger.info(f"Expected Returns (mu):\n{mu}")
    logger.info(f"Covariance Matrix (S):\n{S}")

    # Check if expected returns are too low
    if mu.isna().any():
        logger.error("Error: Expected returns contain NaN values.")
        responseBody = {"TEXT": {"body": "Error: Insufficient or invalid data for expected returns."}}
        return build_response(event, responseBody)

    min_return_threshold = 0.001  # Set a minimum threshold for expected returns
    mu_filtered = mu[mu > min_return_threshold]

    if mu_filtered.empty:
        logger.warning("All assets have low returns. Switching to minimum volatility strategy.")
        try:
            ef = EfficientFrontier(mu, S)
            ef.min_volatility()  # Use minimum volatility as a fallback
            weights = ef.clean_weights()
        except Exception as e:
            logger.error(f"Error in min_volatility optimization: {str(e)}")
            responseBody = {"TEXT": {"body": "Error: Portfolio optimization failed, even with min_volatility fallback."}}
            return build_response(event, responseBody)
    else:
        try:
            ef = EfficientFrontier(mu_filtered, S.loc[mu_filtered.index, mu_filtered.index])
            ef.max_sharpe()
            weights = ef.clean_weights()
        except Exception as e:
            logger.error(f"Error in portfolio optimization: {str(e)}")
            responseBody = {"TEXT": {"body": "Error: Portfolio optimization failed."}}
            return build_response(event, responseBody)
    
    # Convert any numpy types to native Python types.
    weights = {k: float(v) for k, v in weights.items()}
    
    # Compute discrete allocation for a $10,000 portfolio.
    latest_prices = get_latest_prices(df)
    da = DiscreteAllocation(weights, latest_prices, total_portfolio_value=10000)
    allocation, leftover = da.greedy_portfolio()
    allocation = {k: int(v) for k, v in allocation.items()}
    leftover = float(leftover)
    
    logger.info(f"Optimal Weights: {weights}")
    logger.info(f"Discrete Allocation: {allocation}")
    logger.info(f"Remaining Funds: ${leftover:.2f}")
    
    # Build a plain text response.
    response_text = (
        "Optimized Weights: " + json.dumps(weights) + "; " +
        "Discrete Allocation: " + json.dumps(allocation) + "; " +
        "Remaining Funds: $" + f"{leftover:.2f}"
    )
    responseBody = {"TEXT": {"body": response_text}}
    
    return build_response(event, responseBody)

def build_response(event, responseBody):
    """
    Build a function response that mimics the working lambda's structure.
    """
    actionGroup = event.get("actionGroup", "")
    function_name = event.get("function", "")
    messageVersion = event.get("messageVersion", "1.0")
    
    action_response = {
        "actionGroup": actionGroup,
        "function": function_name,
        "functionResponse": {"responseBody": responseBody},
    }
    function_response = {
        "response": action_response,
        "messageVersion": messageVersion,
    }
    logger.info("Function response: {}".format(function_response))
    return function_response
